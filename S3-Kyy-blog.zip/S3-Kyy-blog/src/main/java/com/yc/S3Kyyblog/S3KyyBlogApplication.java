package com.yc.S3Kyyblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S3KyyBlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(S3KyyBlogApplication.class, args);
	}

}
