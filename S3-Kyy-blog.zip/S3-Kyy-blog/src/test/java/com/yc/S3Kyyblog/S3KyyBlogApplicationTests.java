package com.yc.S3Kyyblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3KyyBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
