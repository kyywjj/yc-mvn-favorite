package com.yc.ycblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YcBlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(YcBlogApplication.class, args);
	}

}
