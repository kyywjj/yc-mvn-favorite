package com.yc.ycblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YcBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
